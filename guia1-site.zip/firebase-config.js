// Firebase configuration - paste your config here if you want to replace
const firebaseConfig = {
  apiKey: "AIzaSyDhvZXmusoB02FP6yA5w2RNwmdJadOr4Tg",
  authDomain: "guia1-23459.firebaseapp.com",
  projectId: "guia1-23459",
  storageBucket: "guia1-23459.firebasestorage.app",
  messagingSenderId: "862045707475",
  appId: "1:862045707475:web:612e498abd24c7bd548826"
};

// Optional: if you use FormSubmit, set this to the action URL (ex: "https://formsubmit.co/yourtoken")
// Leave empty to skip email sending
const FORM_SUBMIT_URL = ""; 
