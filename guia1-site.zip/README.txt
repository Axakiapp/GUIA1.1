Guia1 - pacote com Firebase
Conteúdo:
- index.html
- admin.html
- style.css
- app.js (logic for firebase)
- firebase-config.js (contains your firebaseConfig)
- assets/* (logo, icons)

Instruções:
1) Ensure firebase-config.js has your firebaseConfig (already set).
2) Deploy to Vercel (upload root files, make sure index.html is at root).
3) Open admin.html and enter the password Lu32Iv75@ to manage submissions.
4) To receive email copies, set FORM_SUBMIT_URL variable in firebase-config.js (optional).
